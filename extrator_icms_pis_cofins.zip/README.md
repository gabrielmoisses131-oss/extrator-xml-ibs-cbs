# Extrator XML - IBS/CBS (Streamlit)

## Como rodar
1) Instale Python 3.10+  
2) No terminal, dentro da pasta do projeto:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Como usar
- (Opcional) envie a planilha modelo .xlsx
- Envie 1 ou mais XMLs (ou .zip com XMLs dentro)
- O app preenche a aba de LANÇAMENTOS mantendo fórmulas/colunas do seu modelo
