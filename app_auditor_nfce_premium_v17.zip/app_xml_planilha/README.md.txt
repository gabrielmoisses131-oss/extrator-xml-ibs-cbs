AUDITORIA NFC-e — SEFAZ x ADM x FLEX

1) Instale o Python 3.10+ e marque:
   "Add python.exe to PATH"

2) Extraia a pasta e dê duplo clique em rodar_app.bat

Correções:
- Datas ISO do XML agora usam isoparse (não troca dia/mês).
- Base/ICMS do ADM só comparam se existirem/preencherem.