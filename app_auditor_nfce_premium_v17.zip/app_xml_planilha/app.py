import streamlit as st
import pandas as pd
import numpy as np
from io import BytesIO
from datetime import datetime
from dateutil import parser as dtparser
from lxml import etree
import zipfile
import re
import os

# ============================
# Leitura/normalização robusta (ADM/FLEX)
# ============================

def _norm_name(s: str) -> str:
    s = str(s).strip().lower()
    repl = {"ç":"c","ã":"a","á":"a","à":"a","â":"a","é":"e","ê":"e","í":"i","ó":"o","ô":"o","õ":"o","ú":"u"}
    for a,b in repl.items():
        s = s.replace(a,b)
    s = re.sub(r"\s+", " ", s)
    return s

def _digits_only(x):
    s = str(x).strip()
    s = s.replace(".0", "")
    s = re.sub(r"[^0-9]", "", s)
    return s

def _pick_col(df, wants):
    cols = list(df.columns)
    norm = {c:_norm_name(c) for c in cols}
    for w in wants:
        for c,n in norm.items():
            if w in n:
                return c
    return None

def _ensure_serie_numero(df: pd.DataFrame) -> pd.DataFrame:
    # mapeia nomes comuns -> serie/numero
    if "serie" not in df.columns:
        c = _pick_col(df, ["serie", "ser"])
        if c: df = df.rename(columns={c:"serie"})
    if "numero" not in df.columns:
        c = _pick_col(df, ["numero", "nro", "num", "documento", "nf", "nfce"])
        if c: df = df.rename(columns={c:"numero"})

    # normaliza valores
    if "serie" in df.columns:
        df["serie"] = df["serie"].apply(_digits_only).replace("", np.nan)
        df["serie"] = df["serie"].astype("string").str.lstrip("0").replace("", np.nan)
    if "numero" in df.columns:
        df["numero"] = df["numero"].apply(_digits_only).replace("", np.nan)
        df["numero"] = df["numero"].astype("string").str.lstrip("0").replace("", np.nan)

    return df

def read_excel_smart(uploaded_file):
    """Lê Excel tentando descobrir a linha do cabeçalho (quando vem com títulos acima)."""
    try:
        raw = pd.read_excel(uploaded_file, sheet_name=0, header=None)
        best_i, best_score = 0, -1
        for i in range(min(30, len(raw))):
            vals = [_norm_name(v) for v in raw.iloc[i].tolist()]
            score = 0
            if any("serie" in v or v == "ser" for v in vals): score += 2
            if any(("numero" in v) or (v == "num") or ("nro" in v) or (v == "nf") for v in vals): score += 2
            if any(("valor" in v) or ("icms" in v) or ("base" in v) for v in vals): score += 1
            if score > best_score:
                best_i, best_score = i, score
        df = pd.read_excel(uploaded_file, sheet_name=0, header=best_i)
        df = df.dropna(axis=1, how="all")
        return df
    except Exception:
        return pd.read_excel(uploaded_file, sheet_name=0)


st.set_page_config(page_title="Auditor Fiscal NFC-e", page_icon="🛡️", layout="wide")

# -----------------------------
# Premium UI (Lovable-inspired)
# -----------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:root{
  --bg: #0b1220;
  --card: rgba(17,24,39,.72);
  --card2: rgba(17,24,39,.88);
  --border: rgba(148,163,184,.18);
  --muted: rgba(226,232,240,.65);
  --text: rgba(226,232,240,.95);

  --primary: #3b82f6;
  --success: #10b981;
  --warning: #f59e0b;
  --danger: #ef4444;

  --grad-hero: linear-gradient(135deg, #3b82f6 0%, #7c3aed 50%, #db2777 100%);
  --grad-success: linear-gradient(135deg, #10b981 0%, #059669 100%);
  --grad-warning: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  --grad-danger: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);

  --shadow: 0 10px 30px rgba(0,0,0,.35);
  --shadow2: 0 20px 45px rgba(0,0,0,.45);
  --r: 18px;
}

html, body, [class*="css"]  { font-family: 'Plus Jakarta Sans', sans-serif; }

/* Page background */
.stApp{
  background: radial-gradient(1200px 600px at 80% -20%, rgba(59,130,246,.22), transparent 60%),
              radial-gradient(900px 500px at -10% 10%, rgba(16,185,129,.18), transparent 55%),
              radial-gradient(1000px 600px at 50% 120%, rgba(245,158,11,.12), transparent 60%),
              var(--bg);
}

/* Reduce Streamlit chrome */
header[data-testid="stHeader"], footer { visibility: hidden; height: 0; }

/* Generic card */
.l-card{ 
  border: 1px solid var(--border);
  background: rgba(17,24,39,.55);
  backdrop-filter: blur(14px);
  border-radius: var(--r);
  padding: 18px 18px;
  box-shadow: var(--shadow);
}

/* Header hero */
.l-hero{
  border: 1px solid var(--border);
  background: rgba(17,24,39,.55);
  backdrop-filter: blur(18px);
  border-radius: calc(var(--r) + 6px);
  padding: 18px 18px;
  box-shadow: var(--shadow);
  display:flex; align-items:center; justify-content:space-between;
  position: relative; overflow:hidden;
}
.l-hero:before{
  content:"";
  position:absolute; inset:-2px;
  background: radial-gradient(500px 220px at 80% 0%, rgba(59,130,246,.18), transparent 70%),
              radial-gradient(420px 220px at 0% 30%, rgba(16,185,129,.14), transparent 70%);
  pointer-events:none;
}
.l-hero-left{ display:flex; gap:14px; align-items:center; position:relative; }
.l-icon{
  width:46px; height:46px; border-radius: 16px;
  background: var(--grad-hero);
  display:flex; align-items:center; justify-content:center;
  box-shadow: 0 0 40px rgba(59,130,246,.25);
  font-size:22px;
}
.l-title{ margin:0; font-weight:900; font-size:20px; letter-spacing:-.02em; color: var(--text);} 
.l-sub{ margin:2px 0 0 0; font-weight:600; font-size:12.5px; color: var(--muted);} 
.l-badge{
  position:relative;
  display:flex; gap:8px; align-items:center;
  border: 1px solid rgba(16,185,129,.25);
  background: rgba(16,185,129,.12);
  color: #34d399;
  padding: 8px 12px;
  border-radius: 999px;
  font-weight:800; font-size:12.5px;
}

/* Upload cards */
.upload-card{
  border: 2px dashed var(--border);
  border-radius: calc(var(--r) + 6px);
  padding: 18px 18px;
  background: rgba(17,24,39,.45);
  transition: all .25s ease;
  box-shadow: var(--shadow);
}
.upload-card:hover{ transform: translateY(-2px); box-shadow: var(--shadow2); border-color: rgba(148,163,184,.35); }
.upload-card.blue:hover{ border-color: rgba(59,130,246,.55); background: rgba(59,130,246,.05); }
.upload-card.green:hover{ border-color: rgba(16,185,129,.55); background: rgba(16,185,129,.05); }
.upload-card.amber:hover{ border-color: rgba(245,158,11,.55); background: rgba(245,158,11,.05); }
.upload-title{ font-weight:900; font-size:15px; margin-top:8px; }
.upload-desc{ margin:6px 0 12px 0; color: var(--muted); font-size:12.5px; font-weight:600; }

.small-pill{
  display:inline-flex; gap:8px; align-items:center;
  border-radius: 999px;
  padding: 8px 12px;
  border: 1px dashed rgba(148,163,184,.25);
  color: var(--muted);
  font-weight:700;
  font-size:12.5px;
}
.small-pill.ok{ border-style:solid; background: rgba(148,163,184,.08); color: rgba(226,232,240,.92); }

/* Big gradients (Valor/ICMS) */
.grad{
  border: 1px solid var(--border);
  border-radius: calc(var(--r) + 6px);
  padding: 18px 18px;
  background: rgba(17,24,39,.55);
  box-shadow: var(--shadow);
  position: relative; overflow:hidden;
}
.grad:before{
  content:""; position:absolute; inset:-2px; opacity:.55;
  background: radial-gradient(400px 160px at 20% 0%, rgba(59,130,246,.35), transparent 60%);
}
.grad.bluepurp:before{ background: radial-gradient(480px 180px at 18% 0%, rgba(59,130,246,.38), transparent 60%), radial-gradient(420px 160px at 70% 10%, rgba(124,58,237,.30), transparent 65%); }
.grad.green:before{ background: radial-gradient(480px 180px at 18% 0%, rgba(16,185,129,.35), transparent 60%), radial-gradient(420px 160px at 70% 10%, rgba(52,211,153,.18), transparent 65%); }
.grad-label{ position:relative; margin:0; color: var(--muted); font-weight:800; letter-spacing:.06em; text-transform:uppercase; font-size:12px; }
.grad-value{ position:relative; margin:8px 0 0 0; color: var(--text); font-weight:950; font-size:22px; }

/* KPI cards (StatCard vibe) */
.kpi{
  border: 1px solid var(--border);
  border-radius: calc(var(--r) + 6px);
  padding: 18px 18px;
  background: rgba(17,24,39,.55);
  box-shadow: var(--shadow);
  transition: all .25s ease;
  display:flex; align-items:flex-start; justify-content:space-between;
  position:relative; overflow:hidden;
}
.kpi:hover{ transform: translateY(-2px); box-shadow: var(--shadow2); }
.kpi:before{ content:""; position:absolute; right:-28px; top:-28px; width:120px; height:120px; border-radius:999px; background: rgba(59,130,246,.10); opacity:0; transition: opacity .25s ease; }
.kpi:hover:before{ opacity:1; }
.kpi h4{ margin:0; color: var(--muted); font-size:12px; font-weight:900; letter-spacing:.08em; text-transform:uppercase; }
.kpi .num{ margin-top:10px; font-size:28px; font-weight:950; color: var(--text); letter-spacing:-.02em; }
.kpi .sub{ margin-top:6px; color: var(--muted); font-size:12.5px; font-weight:650; }
.kpi .dot{ width:44px; height:44px; border-radius: 14px; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:900; }
.kpi.neutral .dot{ background: var(--grad-hero); box-shadow: 0 0 40px rgba(59,130,246,.22); }
.kpi.success .dot{ background: var(--grad-success); box-shadow: 0 0 40px rgba(16,185,129,.22); }
.kpi.warn .dot{ background: var(--grad-warning); box-shadow: 0 0 40px rgba(245,158,11,.20); }
.kpi.danger .dot{ background: var(--grad-danger); box-shadow: 0 0 40px rgba(239,68,68,.20); }

/* Radio tabs spacing */
div[role="radiogroup"]{ gap: 16px; }

</style>
""", unsafe_allow_html=True)


# -----------------------------
# Utils
# -----------------------------
def norm_txt(s):
    if s is None:
        return ""
    s = str(s).lower().strip()
    repl = str.maketrans("áàâãäéèêëíìîïóòôõöúùûüçñ", "aaaaaeeeeiiiiooooouuuucn")
    s = s.translate(repl)
    for ch in ["\n", "\t", " ", ".", ",", ";", ":", "-", "_", "/", "\\", "(", ")", "[", "]", "{", "}", "%", "º"]:
        s = s.replace(ch, " ")
    return " ".join(s.split())

def to_float(x):
    """Converte valores numéricos preservando casas decimais.

    - XML (NF-e/NFC-e) normalmente vem com decimal em ponto: 43.00
    - Excel/BR pode vir como: 1.234,56 ou 43,00
    - Não remove '.' cegamente (isso quebrava o XML e virava 4300).
    """
    if pd.isna(x):
        return np.nan
    if isinstance(x, (int, float, np.number)):
        return float(x)

    s = str(x).strip()
    if not s:
        return np.nan

    # remove símbolos comuns
    s = s.replace("R$", "").replace("\u00a0", " ").strip()
    s = s.replace(" ", "")

    if "," in s and "." in s:
        # assume formato BR "1.234,56"
        s = s.replace(".", "").replace(",", ".")
    elif "," in s and "." not in s:
        # "123,45"
        s = s.replace(",", ".")

        # "43.00" (XML) ou "4300"
        pass

    try:
        return float(s)
    except:
        return np.nan


def to_date(x):
    if pd.isna(x):
        return pd.NaT
    if isinstance(x, (datetime, pd.Timestamp)):
        return pd.to_datetime(x).date()
    s = str(x).strip()
    if not s:
        return pd.NaT
    try:
        return dtparser.parse(s, dayfirst=True).date()
    except:
        return pd.NaT

def round2(x):
    if pd.isna(x):
        return np.nan
    return float(np.round(x, 2))

def detect_centavos(df, cols):
    """
    Heurística para ADM/FLEX:
    Se a mediana é "grande" e quase tudo é inteiro, assume que está em centavos.
    """
    for c in cols:
        if c in df.columns:
            s = df[c].dropna()
            if not s.empty:
                try:
                    arr = s.astype(float)
                    med = float(np.nanmedian(arr))
                    if med > 1000 and ((arr % 1) == 0).mean() > 0.9:
                        df[c] = df[c] / 100
                except:
                    pass
    return df

def excel_download(df_dict):
    """Gera Excel 'premium' (dashboard + tabela estilizada + filtros + congela painéis)."""
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter", datetime_format="yyyy-mm-dd") as writer:
        workbook = writer.book

        # =========================
        # Formatos
        # =========================
        fmt_title = workbook.add_format({
            "bold": True, "font_size": 16, "font_color": "#1F4E79"
        })
        fmt_sub = workbook.add_format({
            "bold": True, "font_size": 11, "font_color": "#1F4E79"
        })
        fmt_kpi = workbook.add_format({
            "bold": True, "font_size": 14, "align": "center", "valign": "vcenter",
            "bg_color": "#E8F1FB", "border": 1
        })
        fmt_kpi_lbl = workbook.add_format({
            "bold": True, "align": "center", "valign": "vcenter",
            "bg_color": "#F3F6FB", "border": 1
        })

        fmt_header = workbook.add_format({
            "bold": True, "font_color": "white", "bg_color": "#1F4E79",
            "align": "center", "valign": "vcenter", "border": 1
        })
        fmt_text = workbook.add_format({"valign": "vcenter"})
        fmt_wrap = workbook.add_format({"valign": "vcenter", "text_wrap": True})
        fmt_num = workbook.add_format({"num_format": "#,##0.00", "valign": "vcenter"})
        fmt_int = workbook.add_format({"num_format": "0", "valign": "vcenter"})
        fmt_date = workbook.add_format({"num_format": "yyyy-mm-dd", "valign": "vcenter"})

        fmt_ok = workbook.add_format({"font_color": "#006100", "bg_color": "#C6EFCE"})
        fmt_warn = workbook.add_format({"font_color": "#9C5700", "bg_color": "#FFEB9C"})
        fmt_bad = workbook.add_format({"font_color": "#9C0006", "bg_color": "#FFC7CE"})
        fmt_div = workbook.add_format({"font_color": "#7F3F00", "bg_color": "#FCE4D6"})

        zebra = workbook.add_format({"bg_color": "#F7F7F7"})

        # =========================
        # Dashboard (Resumo)
        # =========================
        resumo_name = "RESUMO"
        ws = workbook.add_worksheet(resumo_name)
        writer.sheets[resumo_name] = ws

        ws.set_default_row(18)
        ws.set_column(0, 0, 3)
        ws.set_column(1, 1, 40)
        ws.set_column(2, 6, 18)

        ws.write(0, 1, "Auditoria NFC-e — Resumo", fmt_title)
        ws.write(2, 1, "KPIs", fmt_sub)

        def safe_len(df):
            try:
                return int(len(df))
            except:
                return 0

        sefaz_n = safe_len(df_dict.get("SEFAZ", pd.DataFrame()))
        adm_n = safe_len(df_dict.get("ADM", pd.DataFrame()))
        flex_n = safe_len(df_dict.get("FLEX", pd.DataFrame()))
        alerts_df = df_dict.get("ALERTAS", pd.DataFrame())
        alerts_n = safe_len(alerts_df)

        # KPI cards
        kpis = [("Notas SEFAZ", sefaz_n), ("Notas ADM", adm_n), ("Notas FLEX", flex_n), ("Alertas", alerts_n)]
        row = 4
        col = 1
        for i, (lbl, val) in enumerate(kpis):
            ws.write(row, col + i, lbl, fmt_kpi_lbl)
            ws.write(row + 1, col + i, val, fmt_kpi)

        # Quebras por motivo / status
        ws.write(7, 1, "Distribuição de Alertas", fmt_sub)
        ws.set_column(1, 1, 45)
        ws.set_column(2, 2, 14)

        start_row = 9
        if alerts_df is not None and not alerts_df.empty:
            # Motivos
            motivos = alerts_df["motivo"].fillna("SEM_MOTIVO").value_counts().head(20)
            ws.write(start_row, 1, "Motivo (Top 20)", fmt_header)
            ws.write(start_row, 2, "Qtde", fmt_header)
            for r, (k, v) in enumerate(motivos.items(), start=1):
                ws.write(start_row + r, 1, str(k), fmt_wrap)
                ws.write(start_row + r, 2, int(v), fmt_int)
            # Status
            st_row = start_row
            st_col = 4
            ws.set_column(st_col, st_col, 22)
            ws.set_column(st_col + 1, st_col + 1, 12)
            ws.write(st_row, st_col, "Status ADM", fmt_header)
            ws.write(st_row, st_col + 1, "Qtde", fmt_header)
            for r, (k, v) in enumerate(alerts_df["status_adm"].fillna("SEM").value_counts().items(), start=1):
                ws.write(st_row + r, st_col, str(k), fmt_text)
                ws.write(st_row + r, st_col + 1, int(v), fmt_int)

            ws.write(st_row + 6, st_col, "Status FLEX", fmt_header)
            ws.write(st_row + 6, st_col + 1, "Qtde", fmt_header)
            for r, (k, v) in enumerate(alerts_df["status_flex"].fillna("SEM").value_counts().items(), start=1):
                ws.write(st_row + 6 + r, st_col, str(k), fmt_text)
                ws.write(st_row + 6 + r, st_col + 1, int(v), fmt_int)

            ws.write(start_row, 1, "Sem alertas gerados.", fmt_text)

        # =========================
        # Abas de dados (Tabela bonita)
        # =========================
        def apply_table(sheet, df):
            ws = writer.sheets[sheet]
            try:
                nrows, ncols = df.shape
            except Exception:
                nrows, ncols = 0, 0

            # Evita ws.add_table() (causa OverlappingRange quando o df já foi escrito)
            # Congela cabeçalho
            try:
                ws.freeze_panes(1, 0)
            except Exception:
                pass

            # Autofiltro
            if nrows > 0 and ncols > 0:
                try:
                    ws.autofilter(0, 0, nrows, ncols - 1)
                except Exception:
                    pass

            # Ajuste de colunas (amostra para performance)
            if ncols > 0:
                try:
                    for i, col in enumerate(df.columns):
                        max_len = max(len(str(col)), 8)
                        sample = df.iloc[: min(200, nrows), i].astype(str)
                        if len(sample) > 0:
                            max_len = max(max_len, int(sample.map(len).max()))
                        ws.set_column(i, i, min(max_len + 2, 45))
                except Exception:
                    pass


            apply_table(sheet, df)

        # Cores das abas
        for sheet, color in [("SEFAZ", "#D9E1F2"), ("ADM", "#E2EFDA"), ("FLEX", "#FFF2CC"), ("ALERTAS", "#FCE4D6")]:
            if sheet in writer.sheets:
                writer.sheets[sheet].set_tab_color(color)

    return output.getvalue()


def find_col(df, ideas):
    cols_norm = {c: norm_txt(c) for c in df.columns}
    for want in ideas:
        w = norm_txt(want)
        for c, cn in cols_norm.items():
            if w and w in cn:
                return c
    return None

def safe_get_col(df, ideas, required=True, default=np.nan):
    col = find_col(df, ideas)
    if col is None:
        if required:
            raise KeyError(
                f"Não encontrei coluna parecida com {ideas}. "
                f"Colunas disponíveis: {list(df.columns)}"
            )

            return pd.Series([default] * len(df), index=df.index)
    return df[col]

def normalize_key(x):
    """
    Normaliza série/número para bater entre Excel e XML:
    - remove .0 (quando vem como float)
    - mantém só dígitos
    - remove zeros à esquerda (000123 -> 123)
    """
    if pd.isna(x):
        return ""
    s = str(x).strip()

    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]

    try:
        if isinstance(x, (float, np.floating)) and float(x).is_integer():
            s = str(int(x))
    except:
        pass

    dig = re.sub(r"\D+", "", s)
    if dig == "":
        return s

    dig2 = dig.lstrip("0")
    return dig2 if dig2 != "" else "0"

def looks_like_bad_header(cols):
    cols = list(cols)
    if len(cols) == 0:
        return True
    if sum(str(c).lower().startswith("unnamed") for c in cols) >= max(1, int(len(cols) * 0.6)):
        return True
    if len(cols) >= 3 and all(str(c).strip() == "" for c in cols):
        return True
    if len(cols) == 1 and len(str(cols[0])) > 25:
        return True
    if sum(isinstance(c, (int, float, datetime, pd.Timestamp, np.number)) for c in cols) >= max(1, int(len(cols) * 0.6)):
        return True
    return False

def smart_read_excel(uploaded_file):
    df1 = pd.read_excel(uploaded_file, sheet_name=0)
    if not looks_like_bad_header(df1.columns):
        return df1

    df0 = pd.read_excel(uploaded_file, sheet_name=0, header=None)

    expected = [
        "data", "data venda", "data movto", "emissao", "dt emissao", "data emissao",
        "serie", "série", "numero", "número", "vlr", "vlr total", "vlr. total",
        "valor", "total", "base", "base icms", "icms", "cfop", "aliquota", "alíquota"
    ]
    expected = [norm_txt(x) for x in expected]

    best_i = None
    best_score = -1
    max_rows = min(60, len(df0))

    for i in range(max_rows):
        row = df0.iloc[i].tolist()
        row_norm = [norm_txt(x) for x in row]
        score = 0
        for cell in row_norm:
            for e in expected:
                if e and e in cell:
                    score += 1
        has_data = any("data" in c for c in row_norm)
        has_key = any(("serie" in c) or ("numero" in c) or ("nnf" in c) or ("n nf" in c) for c in row_norm)
        if has_data and has_key:
            score += 3
        if score > best_score:
            best_score = score
            best_i = i

    if best_i is None or best_score < 2:
        df0.columns = [f"col_{i}" for i in range(df0.shape[1])]
        return df0

    header = df0.iloc[best_i].tolist()
    header = [str(h).strip() if not pd.isna(h) else "" for h in header]
    header = [h if h else f"col_{idx}" for idx, h in enumerate(header)]

    df = df0.iloc[best_i + 1:].copy()
    df.columns = header
    df = df.reset_index(drop=True)
    df = df.dropna(how="all")
    return df

# -----------------------------
# XML SEFAZ
# -----------------------------
def parse_xml(xml_bytes: bytes, filename: str | None = None):
    root = etree.fromstring(xml_bytes)

    def xtext(node, xpath):
        el = node.xpath(xpath)
        if not el:
            return None
        return el[0].text if hasattr(el[0], "text") else str(el[0])

    infNFe = root.xpath("//*[local-name()='infNFe']")
    if not infNFe:
        return None
    infNFe = infNFe[0]

    ide_nodes = infNFe.xpath(".//*[local-name()='ide']")
    if not ide_nodes:
        return None
    ide = ide_nodes[0]

    serie = xtext(ide, ".//*[local-name()='serie']")
    numero = xtext(ide, ".//*[local-name()='nNF']")
    dhEmi = xtext(ide, ".//*[local-name()='dhEmi']") or xtext(ide, ".//*[local-name()='dEmi']")
    data = to_date(dhEmi)

    total = infNFe.xpath(".//*[local-name()='ICMSTot']")
    vNF = vBC = vICMS = None
    if total:
        total = total[0]
        vNF = to_float(xtext(total, ".//*[local-name()='vNF']"))
        vBC = to_float(xtext(total, ".//*[local-name()='vBC']"))
        vICMS = to_float(xtext(total, ".//*[local-name()='vICMS']"))

    # SEFAZ (XML) já vem em reais -> NÃO divide por 100 aqui

    # Regra: arquivos XML cujo nome começa com '11' são NFC-e canceladas (padrão informado)
    cancelada = False
    if filename:
        base_name = os.path.basename(str(filename))
        cancelada = base_name.startswith('11')

    return {
        "data": data,
        "serie": normalize_key(serie),
        "numero": normalize_key(numero),
        "valor": round2(vNF),
        "base": round2(vBC),
        "icms": round2(vICMS),
        "fonte": "SEFAZ",
        "cancelada": cancelada,
    }

def load_sefaz_from_upload(uploaded):
    rows = []

    def add_xml_bytes(b, fname=None):
        r = parse_xml(b, filename=fname)
        if r:
            rows.append(r)

    for f in uploaded:
        name = (f.name or "").lower()
        content = f.getvalue()

        if name.endswith(".zip"):
            try:
                with zipfile.ZipFile(BytesIO(content), "r") as z:
                    for n in z.namelist():
                        if n.lower().endswith(".xml"):
                            add_xml_bytes(z.read(n), fname=n)
            except:
                pass
        elif name.endswith(".xml"):
            add_xml_bytes(content, fname=f.name)

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    df["serie"] = df["serie"].astype(str).map(normalize_key)
    df["numero"] = df["numero"].astype(str).map(normalize_key)
    return df

# -----------------------------
# Standardizers
# -----------------------------
def standardize_adm(df):
    out = pd.DataFrame()

    out["data"] = safe_get_col(df, ["data venda", "data movto", "data"], required=True).apply(to_date)

    serie_col = find_col(df, ["serie", "série"])
    if serie_col:
        out["serie"] = df[serie_col].map(normalize_key)

        out["serie"] = "1"

    out["numero"] = safe_get_col(df, ["numero", "número", "nnf", "n nf"], required=True).map(normalize_key)

    out["valor"] = safe_get_col(df, ["vlr total", "vlr. total", "valor", "total", "vlt total"], required=True).apply(to_float)

    # opcionais (ADM normalmente não tem)
    out["base"] = safe_get_col(df, ["base", "vbc", "base icms"], required=False, default=np.nan).apply(to_float)
    out["icms"] = safe_get_col(df, ["icms", "vicms"], required=False, default=np.nan).apply(to_float)
    # Fiscal ADM vem em centavos -> converte para reais
    for c in ["valor", "base", "icms"]:
        out[c] = out[c] / 100
    for c in ["valor", "base", "icms"]:
        out[c] = out[c].apply(round2)

    out["fonte"] = "ADM"
    return out

def standardize_flex(df):
    out = pd.DataFrame()

    out["data"] = safe_get_col(df, ["data", "emissao", "dt emissao", "data emissao"], required=True).apply(to_date)

    serie_col = find_col(df, ["serie", "série"])
    if serie_col:
        out["serie"] = df[serie_col].map(normalize_key)

        out["serie"] = "1"

    out["numero"] = safe_get_col(df, ["numero", "número", "nfce", "nota", "nnf", "n nf"], required=True).map(normalize_key)

    out["valor"] = safe_get_col(df, ["valor", "total", "liquido", "líquido"], required=True).apply(to_float)
    out["base"]  = safe_get_col(df, ["base icms", "base", "vbc"], required=False, default=np.nan).apply(to_float)
    out["icms"]  = safe_get_col(df, ["icms", "vicms"], required=False, default=np.nan).apply(to_float)

    # FLEX pode vir em centavos
    out = detect_centavos(out, ["valor", "base", "icms"])
    for c in ["valor", "base", "icms"]:
        out[c] = out[c].apply(round2)

    grp = out.groupby(["data", "serie", "numero"], as_index=False)[["valor", "base", "icms"]].sum()
    grp["fonte"] = "FLEX"
    return grp

# -----------------------------
# Auditoria
# -----------------------------
def audit(sefaz, adm, flex):
    '''
    Auditoria focada em VALORES (ignora DATA como chave principal).

    Match principal: Série + Número
    - Se existir em ADM/FLEX com a mesma Série+Número, considera a nota "existente"
    - Se houver múltiplas linhas com a mesma Série+Número (datas diferentes), escolhe a melhor
      comparando os valores com SEFAZ (menor diferença), e marca status MULTIPLO.

    Alertas:
    - NAO_ENCONTRADO (não existe por Série+Número)
    - Divergência de VALOR / BASE / ICMS (quando existe)
    '''
    if sefaz.empty:
        return pd.DataFrame(columns=[
            "data","serie","numero",
            "status_adm","status_flex","motivo",
            "valor_sefaz","base_sefaz","icms_sefaz",
            "data_adm","serie_adm","valor_adm","base_adm","icms_adm",
            "data_flex","serie_flex","valor_flex","base_flex","icms_flex",
        ])

    k_key = ["serie", "numero"]

    # agrupa por Série+Número
    def build_group(df):
        if df.empty:
            return {}
        return { k: sub for k, sub in df.groupby(k_key) }

    adm_g  = build_group(adm)
    flex_g = build_group(flex)

    alerts = []

    def cmp(a, b):
        if pd.isna(a) and pd.isna(b):
            return True
        return np.isclose(a, b, atol=0.01, equal_nan=True)

    def pick_best(sub, r_sefaz):
        """Escolhe a linha mais provável quando há duplicidade (datas diferentes)."""
        if sub is None or len(sub) == 0:
            return None, "NAO_ENCONTRADO"
        if len(sub) == 1:
            return sub.iloc[0], "OK"

        # Score por proximidade dos valores (prioriza VALOR)
        def score(row):
            s = 0.0
            # valor sempre pesa mais
            if pd.notna(r_sefaz.get("valor", np.nan)) and pd.notna(row.get("valor", np.nan)):
                s += abs(float(r_sefaz["valor"]) - float(row["valor"])) * 100
            # base/icms se existirem
            if pd.notna(r_sefaz.get("base", np.nan)) and pd.notna(row.get("base", np.nan)):
                s += abs(float(r_sefaz["base"]) - float(row["base"]))
            if pd.notna(r_sefaz.get("icms", np.nan)) and pd.notna(row.get("icms", np.nan)):
                s += abs(float(r_sefaz["icms"]) - float(row["icms"]))
            # bônus se data bate (não é chave, mas ajuda a escolher)
            if str(row.get("data", "")) == str(r_sefaz.get("data", "")):
                s -= 0.5
            return s

        best_idx = sub.apply(score, axis=1).astype(float).idxmin()
        return sub.loc[best_idx], "MULTIPLO"

    def add_alert(r_sefaz, status_adm, status_flex, motivo, r_adm=None, r_flex=None):
        alerts.append({
            "data": r_sefaz.get("data", np.nan),
            "serie": r_sefaz.get("serie", np.nan),
            "numero": r_sefaz.get("numero", np.nan),

            "status_adm": status_adm,
            "status_flex": status_flex,
            "motivo": motivo,

            "valor_sefaz": r_sefaz.get("valor", np.nan),
            "base_sefaz": r_sefaz.get("base", np.nan),
            "icms_sefaz": r_sefaz.get("icms", np.nan),

            "data_adm":  (r_adm.get("data", np.nan)  if r_adm is not None else np.nan),
            "serie_adm": (r_adm.get("serie", np.nan) if r_adm is not None else np.nan),
            "valor_adm": (r_adm.get("valor", np.nan) if r_adm is not None else np.nan),
            "base_adm":  (r_adm.get("base", np.nan)  if r_adm is not None else np.nan),
            "icms_adm":  (r_adm.get("icms", np.nan)  if r_adm is not None else np.nan),

            "data_flex":  (r_flex.get("data", np.nan)  if r_flex is not None else np.nan),
            "serie_flex": (r_flex.get("serie", np.nan) if r_flex is not None else np.nan),
            "valor_flex": (r_flex.get("valor", np.nan) if r_flex is not None else np.nan),
            "base_flex":  (r_flex.get("base", np.nan)  if r_flex is not None else np.nan),
            "icms_flex":  (r_flex.get("icms", np.nan)  if r_flex is not None else np.nan),
        })

    for _, r in sefaz.iterrows():
        key = (r["serie"], r["numero"])

        adm_sub  = adm_g.get(key)
        flex_sub = flex_g.get(key)

        r_adm, st_adm = pick_best(adm_sub, r)
        r_flex, st_flex = pick_best(flex_sub, r)

        # Existência
        status_adm = "SEM_ARQUIVO" if adm.empty else st_adm
        status_flex = "SEM_ARQUIVO" if flex.empty else st_flex

        if status_adm in ["SEM_ARQUIVO", "NAO_ENCONTRADO"] or status_flex in ["SEM_ARQUIVO", "NAO_ENCONTRADO"]:
            motivos = []
            if status_adm == "SEM_ARQUIVO":
                motivos.append("ADM não carregou")
            elif status_adm == "NAO_ENCONTRADO":
                motivos.append("Nota NÃO encontrada no ADM (Série+Número)")
            elif status_adm == "MULTIPLO":
                motivos.append("ADM: múltiplas linhas (datas diferentes)")

            if status_flex == "SEM_ARQUIVO":
                motivos.append("FLEX não carregou")
            elif status_flex == "NAO_ENCONTRADO":
                motivos.append("Nota NÃO encontrada no FLEX (Série+Número)")
            elif status_flex == "MULTIPLO":
                motivos.append("FLEX: múltiplas linhas (datas diferentes)")

            add_alert(r, status_adm, status_flex, " | ".join(motivos), r_adm=r_adm, r_flex=r_flex)
            continue

        # Agora: existe. Se MULTIPLO, avisa mas continua comparando valores
        if status_adm == "MULTIPLO" or status_flex == "MULTIPLO":
            motivos = []
            if status_adm == "MULTIPLO":
                motivos.append("ADM: múltiplas linhas (escolhida a mais próxima por valores)")
            if status_flex == "MULTIPLO":
                motivos.append("FLEX: múltiplas linhas (escolhida a mais próxima por valores)")
            add_alert(r, status_adm, status_flex, " | ".join(motivos), r_adm=r_adm, r_flex=r_flex)

        # Divergência VALOR
        if r_adm is not None and not cmp(r.get("valor", np.nan), r_adm.get("valor", np.nan)):
            add_alert(r, status_adm, status_flex, "Divergência de VALOR (ADM)", r_adm=r_adm, r_flex=r_flex)

        if r_flex is not None and not cmp(r.get("valor", np.nan), r_flex.get("valor", np.nan)):
            add_alert(r, status_adm, status_flex, "Divergência de VALOR (FLEX)", r_adm=r_adm, r_flex=r_flex)

        # Divergência BASE/ICMS (só se existir dos dois lados)
        if r_adm is not None and pd.notna(r_adm.get("base", np.nan)) and pd.notna(r.get("base", np.nan)):
            if not cmp(r["base"], r_adm["base"]):
                add_alert(r, status_adm, status_flex, "Divergência de BASE (ADM)", r_adm=r_adm, r_flex=r_flex)

        if r_adm is not None and pd.notna(r_adm.get("icms", np.nan)) and pd.notna(r.get("icms", np.nan)):
            if not cmp(r["icms"], r_adm["icms"]):
                add_alert(r, status_adm, status_flex, "Divergência de ICMS (ADM)", r_adm=r_adm, r_flex=r_flex)

        if r_flex is not None and pd.notna(r_flex.get("base", np.nan)) and pd.notna(r.get("base", np.nan)):
            if not cmp(r["base"], r_flex["base"]):
                add_alert(r, status_adm, status_flex, "Divergência de BASE (FLEX)", r_adm=r_adm, r_flex=r_flex)

        if r_flex is not None and pd.notna(r_flex.get("icms", np.nan)) and pd.notna(r.get("icms", np.nan)):
            if not cmp(r["icms"], r_flex["icms"]):
                add_alert(r, status_adm, status_flex, "Divergência de ICMS (FLEX)", r_adm=r_adm, r_flex=r_flex)

    df_alerts = pd.DataFrame(alerts)
    if not df_alerts.empty:
        df_alerts = df_alerts.drop_duplicates().sort_values(["serie","numero","motivo"])
    return df_alerts



def build_full_table(sefaz_df: pd.DataFrame, adm_df: pd.DataFrame, flex_df: pd.DataFrame, alerts_df: pd.DataFrame) -> pd.DataFrame:
    """Gera uma tabela 'completa' (todas as notas do SEFAZ) com status ADM/FLEX e motivo.

    - Base: universo SEFAZ
    - Merge ADM/FLEX por (serie, numero)
    - Motivo padrão: 'Conferido'
    - Se a nota aparecer em alerts_df, o motivo vira a concatenação dos motivos (por nota)
    """
    sef = sefaz_df.copy() if isinstance(sefaz_df, pd.DataFrame) else pd.DataFrame()
    if sef is None or sef.empty:
        return pd.DataFrame()

    # garante colunas básicas
    for c in ["data","serie","numero","valor","base","icms"]:
        if c not in sef.columns:
            sef[c] = np.nan

    # renomeia colunas SEFAZ para não conflitar
    out = sef.rename(columns={
        "valor": "valor_sefaz",
        "base": "base_sefaz",
        "icms": "icms_sefaz",
        "data": "data_sefaz",
    }).copy()

    # ADM
    adm = adm_df.copy() if isinstance(adm_df, pd.DataFrame) else pd.DataFrame()
    if adm is not None and not adm.empty and {"serie","numero"}.issubset(adm.columns):
        adm2 = adm.rename(columns={
            "valor": "valor_adm",
            "base": "base_adm",
            "icms": "icms_adm",
            "data": "data_adm",
        })
        # garante tipos iguais para merge
        out[["serie","numero"]] = out[["serie","numero"]].astype(str)
        adm2[["serie","numero"]] = adm2[["serie","numero"]].astype(str)
        out = out.merge(
            adm2[["serie","numero","data_adm","valor_adm","base_adm","icms_adm"]],
            on=["serie","numero"],
            how="left",
        )
    else:
        out["data_adm"] = np.nan
        out["valor_adm"] = np.nan
        out["base_adm"] = np.nan
        out["icms_adm"] = np.nan

    # FLEX
    flex = flex_df.copy() if isinstance(flex_df, pd.DataFrame) else pd.DataFrame()
    if flex is not None and not flex.empty and {"serie","numero"}.issubset(flex.columns):
        flex2 = flex.rename(columns={
            "valor": "valor_flex",
            "base": "base_flex",
            "icms": "icms_flex",
            "data": "data_flex",
        })
        # garante tipos iguais para merge
        out[["serie","numero"]] = out[["serie","numero"]].astype(str)
        flex2[["serie","numero"]] = flex2[["serie","numero"]].astype(str)
        out = out.merge(
            flex2[["serie","numero","data_flex","valor_flex","base_flex","icms_flex"]],
            on=["serie","numero"],
            how="left",
        )
    else:
        out["data_flex"] = np.nan
        out["valor_flex"] = np.nan
        out["base_flex"] = np.nan
        out["icms_flex"] = np.nan
    # status: OK se achou linha, NAO_ENCONTRADO caso contrário
    out["status_adm"] = np.where(out["valor_adm"].notna(), "OK", "NAO_ENCONTRADO")
    out["status_flex"] = np.where(out["valor_flex"].notna(), "OK", "NAO_ENCONTRADO")

    # motivo padrão
    out["motivo"] = "Conferido"

    al = alerts_df.copy() if isinstance(alerts_df, pd.DataFrame) else pd.DataFrame()
    if al is not None and not al.empty and {"serie","numero","motivo"}.issubset(al.columns):
        g = (al[["serie","numero","motivo","status_adm","status_flex"]]
             .copy())
        # agrega motivos por nota
        motivos = (g.groupby(["serie","numero"])["motivo"]
                   .apply(lambda s: " | ".join(pd.unique(s.astype(str))))
                   .reset_index(name="motivo_alerta"))
        out[["serie","numero"]] = out[["serie","numero"]].astype(str)
        motivos[["serie","numero"]] = motivos[["serie","numero"]].astype(str)
        out = out.merge(motivos, on=["serie","numero"], how="left")
        out["motivo"] = np.where(out["motivo_alerta"].notna(), out["motivo_alerta"], out["motivo"])
        out = out.drop(columns=["motivo_alerta"])

        # se alertas trouxerem status mais específicos, usa-os
        if "status_adm" in g.columns:
            st_adm = (g.groupby(["serie","numero"])["status_adm"]
                      .apply(lambda s: pd.unique(s.astype(str))[-1])
                      .reset_index(name="_status_adm"))
            out[["serie","numero"]] = out[["serie","numero"]].astype(str)
            st_adm[["serie","numero"]] = st_adm[["serie","numero"]].astype(str)
            out = out.merge(st_adm, on=["serie","numero"], how="left")
            out["status_adm"] = np.where(out["_status_adm"].notna(), out["_status_adm"], out["status_adm"])
            out = out.drop(columns=["_status_adm"])
        if "status_flex" in g.columns:
            st_fx = (g.groupby(["serie","numero"])["status_flex"]
                     .apply(lambda s: pd.unique(s.astype(str))[-1])
                     .reset_index(name="_status_flex"))
            out[["serie","numero"]] = out[["serie","numero"]].astype(str)
            st_fx[["serie","numero"]] = st_fx[["serie","numero"]].astype(str)
            out = out.merge(st_fx, on=["serie","numero"], how="left")
            out["status_flex"] = np.where(out["_status_flex"].notna(), out["_status_flex"], out["status_flex"])
            out = out.drop(columns=["_status_flex"])

    return out

# -----------------------------
# UI




def normalize_keys(df):
    for col in ["serie", "numero"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.replace(".0", "", regex=False)
                .str.replace(",", "", regex=False)
                .str.strip()
            )
    return df

def normalize_table(df: pd.DataFrame, fonte: str, dividir_por_100: bool=False) -> pd.DataFrame:
    """Normaliza qualquer tabela (CSV/Excel) para o formato padrão:
    data, serie, numero, valor, base, icms, fonte

    Robusto para planilhas com cabeçalhos variados: tenta match exato (normalizado)
    e, se não encontrar, usa heurísticas por substring (ex.: 'serie', 'num', 'valor', 'icms').
    """
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=["data","serie","numero","valor","base","icms","fonte"])

    # mapa: nome_normalizado -> nome_original
    cols = {norm_txt(c): c for c in df.columns}

    def pick(primary, fallbacks):
        for k in [primary] + list(fallbacks):
            if k in cols:
                return cols[k]
        return None

    def pick_contains(tokens, prefer_tokens=None):
        """Retorna a primeira coluna cujo nome normalizado contém TODOS tokens.
        prefer_tokens (opcional) prioriza colunas que contenham algum desses tokens."""
        norm_names = list(cols.keys())
        cand = []
        for nn in norm_names:
            ok = True
            for t in tokens:
                if t not in nn:
                    ok = False
                    break
            if ok:
                cand.append(nn)
        if not cand:
            return None
        if prefer_tokens:
            # prioriza quem contém token preferencial
            for pt in prefer_tokens:
                for nn in cand:
                    if pt in nn:
                        return cols[nn]
        return cols[cand[0]]

    # tentativas (match exato)
    c_data = pick("data", ["dt", "data venda", "data movto", "data_movto", "dtemi", "dhemi"])
    c_serie = pick("serie", ["série", "ser", "serie_nf", "serie nfe", "serie nfce", "serie cupom", "serie documento"])
    c_num   = pick("numero", ["número", "num", "n nf", "nnf", "nf", "numero nf", "numero nota", "numero documento", "numero cupom", "no", "nro"])
    c_val   = pick("valor", ["vlr total", "vltotal", "valor total", "vl tot", "vl total", "valor nota", "vnf", "v_nf", "total", "vlcont", "vltotnf"])
    c_base  = pick("base", ["base icms", "vlbcicms", "bc icms", "vbc", "v_bc", "baseicms", "base_calculo", "base calculo"])
    c_icms  = pick("icms", ["valor icms", "vlicms", "icms total", "vl icms", "vicms", "v_icms", "valor_do_icms"])

    # heurísticas (se faltar)
    if c_serie is None:
        c_serie = pick_contains(["serie"])
    if c_num is None:
        c_num = pick_contains(["num"], prefer_tokens=["numero","nnf","nro"]) or pick_contains(["nf"], prefer_tokens=["numero","num"])
    if c_val is None:
        c_val = pick_contains(["valor"], prefer_tokens=["total","vl"]) or pick_contains(["total"])
    if c_icms is None:
        c_icms = pick_contains(["icms"], prefer_tokens=["valor","vl"])
    if c_base is None:
        # base costuma vir como 'base icms' / 'bc icms' / 'vbc'
        c_base = pick_contains(["base"], prefer_tokens=["icms","bc","calculo"]) or pick_contains(["bc"], prefer_tokens=["icms"])

    out = pd.DataFrame()
    out["data"] = df[c_data].astype(str).str[:10] if c_data is not None else ""
    out["serie"] = df[c_serie] if c_serie is not None else np.nan
    out["numero"] = df[c_num] if c_num is not None else np.nan

    def to_num(series):
        s = series.astype(str).str.strip()
        # remove moeda e espaços
        s = s.str.replace("R$", "", regex=False).str.replace(" ", "", regex=False)
        # pt-BR -> float
        s = s.str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
        return pd.to_numeric(s, errors="coerce")

    out["valor"] = to_num(df[c_val]) if c_val is not None else np.nan
    out["base"]  = to_num(df[c_base]) if c_base is not None else np.nan
    out["icms"]  = to_num(df[c_icms]) if c_icms is not None else np.nan

    if dividir_por_100:
        out["valor"] = out["valor"] / 100.0
        out["base"]  = out["base"] / 100.0
        out["icms"]  = out["icms"] / 100.0

    out["fonte"] = fonte

    # limpeza / tipos
    out = out.dropna(subset=["numero"])
    # serie pode vir vazia em algumas planilhas: tenta numérico, senão 0
    out["serie"]  = pd.to_numeric(out["serie"], errors="coerce").fillna(0).astype(int)
    out["numero"] = pd.to_numeric(out["numero"], errors="coerce").astype(int)
    for c in ["valor","base","icms"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").fillna(0.0).astype(float)

    return out

def read_csv_any(file_like, fonte: str = "SEFAZ", dividir_por_100: bool = False):
    try:
        file_like.seek(0)
    except Exception:
        pass
    try:
        df = pd.read_csv(file_like, sep=None, engine="python")
    except Exception:
        file_like.seek(0)
        df = pd.read_csv(file_like)
    return normalize_table(df, fonte=fonte, dividir_por_100=dividir_por_100)

def read_sefaz_xml_file(file_like):
    # UploadedFile pode manter ponteiro no fim após reruns; use getvalue/seek
    try:
        content = file_like.getvalue()
    except Exception:
        file_like.seek(0)
        content = file_like.read()
    xml = content.decode("utf-8", errors="ignore") if isinstance(content, (bytes, bytearray)) else str(content)
    if "parse_sefaz_xml_string" in globals():
        return parse_sefaz_xml_string(xml, filename=os.path.basename(path))
    return pd.DataFrame(columns=["data","serie","numero","valor","base","icms","fonte","cancelada"])

def read_sefaz_zip(file_like):
    import zipfile as _zf
    from io import BytesIO as _BytesIO
    try:
        data = file_like.getvalue()
    except Exception:
        file_like.seek(0)
        data = file_like.read()
    buf = _BytesIO(data)
    rows=[]
    with _zf.ZipFile(buf) as z:
        for n in z.namelist():
            if n.lower().endswith(".xml"):
                xml = z.read(n).decode("utf-8", errors="ignore")
                if "parse_sefaz_xml_string" in globals():
                    df = parse_sefaz_xml_string(xml, filename=n)
                    if not df.empty:
                        rows.append(df)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["data","serie","numero","valor","base","icms","fonte"])

def read_excel_any(file_like, fonte, dividir_por_100=False):
    try:
        file_like.seek(0)
    except Exception:
        pass
    df = pd.read_excel(file_like)
    return normalize_table(df, fonte=fonte, dividir_por_100=dividir_por_100)

def parse_sefaz_xml_string(xml: str, filename: str | None = None) -> pd.DataFrame:
    """Parse de um XML da SEFAZ (texto) e retorna DataFrame normalizado."""
    try:
        row = parse_xml(xml.encode("utf-8"), filename=filename)
        return pd.DataFrame([row])
    except Exception:
        return pd.DataFrame(columns=["data","serie","numero","valor","base","icms","fonte","cancelada"])
def money_br(v):
    try:
        if pd.isna(v):
            return "—"
        return f"R$ {float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return "—"

def render_header():
    st.markdown("""<div class="l-hero">
      <div class="l-hero-left">
        <div class="l-icon">🛡️</div>
        <div>
          <p class="l-title">Auditor Fiscal NFC-e</p>
          <p class="l-sub">Conferência inteligente SEFAZ × Fiscal ADM × Fiscal Flex</p>
        </div>
      </div>
      <div class="l-badge">✅ Sistema Operacional</div>
    </div>""", unsafe_allow_html=True)

def upload_block(col, title, desc, key, border_class, types):
    colors = {"blue":"#2563eb","green":"#059669","amber":"#b45309"}
    with col:
        st.markdown(f"""<div class="upload-card {border_class}">
          <div style="font-size:32px; line-height: 1;">📄</div>
          <div class="upload-title" style="color: {colors.get(border_class,'#111827')};">{title}</div>
          <p class="upload-desc">{desc}</p>
        """, unsafe_allow_html=True)

        up = st.file_uploader(" ", type=types, key=key, label_visibility="collapsed")
        if up is not None:
            st.markdown(f'<span class="small-pill ok">✅ {up.name}</span>', unsafe_allow_html=True)

            st.markdown('<span class="small-pill">⬆️ Clique ou arraste o arquivo</span>', unsafe_allow_html=True)
        st.markdown("""</div>""", unsafe_allow_html=True)
        return up


def calc_metrics(sefaz_df: pd.DataFrame, adm_df: pd.DataFrame, flex_df: pd.DataFrame, alerts_df: pd.DataFrame) -> dict:
    """Calcula KPIs do painel.

    IMPORTANTE:
    - A tabela (alerts_df) só contém *problemas* (ausências/divergências/múltiplos).
      Então "conferidas" não pode ser contada dentro dela.
    - Todos os contadores (conferidas/divergentes/ausentes) devem ser por NOTA (série+número),
      e não por linha, porque uma mesma nota pode gerar mais de um alerta.
    """
    sef = sefaz_df.copy() if isinstance(sefaz_df, pd.DataFrame) else pd.DataFrame()
    al = alerts_df.copy() if isinstance(alerts_df, pd.DataFrame) else pd.DataFrame()

    def _sum_numeric(df: pd.DataFrame, col: str) -> float:
        if df is None or df.empty or col not in df.columns:
            return 0.0
        s = pd.to_numeric(df[col], errors='coerce').fillna(0)
        return float(s.sum())

    def _key_df(df: pd.DataFrame) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame(columns=['serie','numero'])
        if not {'serie','numero'}.issubset(df.columns):
            return pd.DataFrame(columns=['serie','numero'])
        k = df[['serie','numero']].dropna().copy()
        # normaliza tipos pra evitar mismatch 201 vs 201.0
        k['serie'] = k['serie'].astype(str).str.replace('.0','',regex=False).str.strip()
        k['numero'] = k['numero'].astype(str).str.replace('.0','',regex=False).str.strip()
        return k

    # Total de notas: SEMPRE vem do SEFAZ (universo)
    keys_sefaz = _key_df(sef)
    total_notas = int(keys_sefaz.drop_duplicates().shape[0]) if not keys_sefaz.empty else int(len(sef))

    # Totais monetários: preferir SEFAZ direto (é o "universo").
    # Se por algum motivo não existir, tenta pegar das colunas *_sefaz do df final.
    valor_total = _sum_numeric(sef, 'valor') or _sum_numeric(al, 'valor_sefaz')
    icms_total = _sum_numeric(sef, 'icms') or _sum_numeric(al, 'icms_sefaz')

    # Se não há alertas, então tudo conferido (desde que ADM/FLEX carregados).
    keys_alertas = _key_df(al)
    total_problemas = int(keys_alertas.drop_duplicates().shape[0]) if not keys_alertas.empty else 0

    # Divergentes (por nota)
    divergentes = 0
    if not al.empty and 'motivo' in al.columns and {'serie','numero'}.issubset(al.columns):
        mask_div = al['motivo'].astype(str).str.contains('Diverg', case=False, na=False)
        divergentes = int(_key_df(al[mask_div]).drop_duplicates().shape[0])

    # Ausentes (por nota)
    ausentes_adm = 0
    if not al.empty and 'status_adm' in al.columns and {'serie','numero'}.issubset(al.columns):
        mask_aus = al['status_adm'].astype(str).isin(['NAO_ENCONTRADO','SEM_ARQUIVO'])
        ausentes_adm = int(_key_df(al[mask_aus]).drop_duplicates().shape[0])

    ausentes_flex = 0
    if not al.empty and 'status_flex' in al.columns and {'serie','numero'}.issubset(al.columns):
        mask_aus = al['status_flex'].astype(str).isin(['NAO_ENCONTRADO','SEM_ARQUIVO'])
        ausentes_flex = int(_key_df(al[mask_aus]).drop_duplicates().shape[0])

    # Conferidas: total - notas que apareceram em QUALQUER alerta
    conferidas = max(total_notas - total_problemas, 0)

    return {
        # chaves usadas no painel atual
        'valor_total': float(valor_total),
        'icms_total': float(icms_total),
        'total_notas': int(total_notas),
        'conferidas': int(conferidas),
        'divergentes': int(divergentes),
        'ausentes_adm': int(ausentes_adm),
        'ausentes_flex': int(ausentes_flex),

        # aliases (mantém compatibilidade)
        'total_valor_sefaz': float(valor_total),
        'total_icms_apurado': float(icms_total),
    }



def style_table(df):
    if df is None or getattr(df, 'empty', True):
        return df

    d = df.copy()

    def row_style(r):
        motivo = str(r.get("motivo",""))
        if "Divergência" in motivo:
            return ["background-color: #fff1f2"] * len(r)
        if r.get("status_adm") == "NAO_ENCONTRADO" or r.get("status_flex") == "NAO_ENCONTRADO":
            return ["background-color: #fffbeb"] * len(r)
        return [""] * len(r)

    sty = d.style.apply(row_style, axis=1)

    for col in [c for c in d.columns if str(c).startswith("status_")]:
        sty = sty.applymap(
            lambda v: (
                "color:#065f46;background:#d1fae5;border-radius:999px;padding:2px 8px;display:inline-block;font-weight:800;"
                if str(v)=="OK" else
                "color:#7c2d12;background:#ffedd5;border-radius:999px;padding:2px 8px;display:inline-block;font-weight:800;"
                if ("DIVERGE" in str(v) or "MULTIPLO" in str(v)) else
                "color:#7f1d1d;background:#fee2e2;border-radius:999px;padding:2px 8px;display:inline-block;font-weight:900;"
                if ("NAO_ENCONTRADO" in str(v) or "SEM_ARQUIVO" in str(v)) else ""
            ),
            subset=[col]
        )
    return sty

render_header()
st.write("")
st.markdown('<div class="l-card"><h3 style="margin:0;font-weight:900;">Importar Dados</h3><p style="margin:6px 0 0 0;color:rgba(17,24,39,.6);font-size:13px;">Carregue os arquivos das três fontes para iniciar a conferência</p></div>', unsafe_allow_html=True)
st.write("")

c1, c2, c3 = st.columns(3, gap="large")
up_sefaz = upload_block(c1, "Arquivo SEFAZ", "XML (zip), CSV ou Excel da Secretaria da Fazenda", "up_sefaz", "blue", ["xml","zip","csv","xlsx","xls"])
up_adm   = upload_block(c2, "Fiscal ADM", "Planilha Excel do sistema Fiscal ADM", "up_adm", "green", ["xlsx","xls"])
up_flex  = upload_block(c3, "Fiscal Flex", "Planilha Excel do sistema Fiscal Flex", "up_flex", "amber", ["xlsx","xls"])

sefaz_df = pd.DataFrame()
adm_df = pd.DataFrame()
flex_df = pd.DataFrame()
alerts = pd.DataFrame()
full_df = pd.DataFrame()

if up_sefaz is not None:
    name = up_sefaz.name.lower()
    if name.endswith(".csv"):
        sefaz_df = read_csv_any(up_sefaz, fonte="SEFAZ", dividir_por_100=False)
    elif name.endswith(".zip"):
        sefaz_df = read_sefaz_zip(up_sefaz)
    elif name.endswith(".xlsx") or name.endswith(".xls"):
        sefaz_df = read_excel_any(up_sefaz, fonte="SEFAZ", dividir_por_100=False)

        sefaz_df = read_sefaz_xml_file(up_sefaz)


if up_adm is not None:
    adm_df = read_excel_any(up_adm, fonte="ADM", dividir_por_100=True)

if up_flex is not None:
    flex_df = read_excel_any(up_flex, fonte="FLEX", dividir_por_100=False)

if up_sefaz is not None and (sefaz_df is None or sefaz_df.empty):
    st.warning("Arquivo SEFAZ carregado, mas não consegui identificar as colunas (preciso de Nº/Série/Valor). Se for CSV, confirme se tem colunas como numero/serie/valor/base/icms.")
# Auditoria (ignora data, foca valores)
if not sefaz_df.empty and "cancelada" in sefaz_df.columns:
    sefaz_df = sefaz_df[~sefaz_df["cancelada"].fillna(False)]

if not sefaz_df.empty:
    alerts = audit(sefaz_df, adm_df, flex_df)
    full_df = build_full_table(sefaz_df, adm_df, flex_df, alerts)

st.write("")

m = calc_metrics(sefaz_df, adm_df, flex_df, alerts)
# Se a tabela completa existir, recalcula contadores (mais fiel ao filtro UI)
if isinstance(full_df, pd.DataFrame) and not full_df.empty:
    try:
        m['total_notas'] = int(full_df[['serie','numero']].drop_duplicates().shape[0])
        m['divergentes'] = int(full_df[full_df['motivo'].astype(str).str.contains('diverg', case=False, na=False)][['serie','numero']].drop_duplicates().shape[0])
        m['ausentes_adm'] = int(full_df[full_df['status_adm'].astype(str).isin(['NAO_ENCONTRADO','SEM_ARQUIVO'])][['serie','numero']].drop_duplicates().shape[0])
        m['ausentes_flex'] = int(full_df[full_df['status_flex'].astype(str).isin(['NAO_ENCONTRADO','SEM_ARQUIVO'])][['serie','numero']].drop_duplicates().shape[0])
        m['conferidas'] = int(full_df[full_df['motivo'].astype(str).str.lower().eq('conferido')][['serie','numero']].drop_duplicates().shape[0])
    except Exception:
        pass
# Fallback: se por algum motivo o DataFrame SEFAZ não ficou disponível neste ciclo,
# calculamos os cards a partir da própria tabela de alertas (que já contém valor/base/icms da SEFAZ).
if (m.get("total_notas", 0) == 0) and (not alerts.empty) and ("valor_sefaz" in alerts.columns):
    sef = alerts[alerts["valor_sefaz"].notna()].copy()
    # chaves únicas por (serie, numero) para não contar duplicado
    if "serie" in sef.columns and "numero" in sef.columns:
        sef["_k"] = sef["serie"].astype(str) + "-" + sef["numero"].astype(str)
        total_notas = sef["_k"].nunique()

        total_notas = len(sef)
    valor_total = pd.to_numeric(sef["valor_sefaz"], errors="coerce").fillna(0).sum()
    icms_total = pd.to_numeric(sef.get("icms_sefaz", 0), errors="coerce").fillna(0).sum()

    # conferidas = OK nos 3
    conferidas = 0
    if "status_adm" in alerts.columns and "status_flex" in alerts.columns:
        conferidas = int(((alerts["status_adm"] == "OK") & (alerts["status_flex"] == "OK") & (~alerts["motivo"].astype(str).str.contains("Diverg", case=False, na=False))).sum())

    divergentes = 0
    if "motivo" in alerts.columns:
        divergentes = int(alerts["motivo"].astype(str).str.contains("Diverg", case=False, na=False).sum())

    aus_adm = 0
    if "status_adm" in alerts.columns:
        aus_adm = int(alerts["status_adm"].isin(["NAO_ENCONTRADO", "SEM_ARQUIVO"]).sum())

    aus_flex = 0
    if "status_flex" in alerts.columns:
        aus_flex = int(alerts["status_flex"].isin(["NAO_ENCONTRADO", "SEM_ARQUIVO"]).sum())

    m.update({
        "valor_total": float(valor_total),
        "icms_total": float(icms_total),
        "total_notas": int(total_notas),
        "conferidas": int(conferidas),
        "divergentes": int(divergentes),
        "ausentes_adm": int(aus_adm),
        "ausentes_flex": int(aus_flex),
    })


sum1, sum2 = st.columns(2, gap="large")
with sum1:
    st.markdown(f'<div class="grad bluepurp"><p class="grad-label">Valor Total SEFAZ</p><p class="grad-value">{money_br(m.get("valor_total"))}</p></div>', unsafe_allow_html=True)
with sum2:
    st.markdown(f'<div class="grad green"><p class="grad-label">Total ICMS Apurado</p><p class="grad-value">{money_br(m.get("icms_total"))}</p></div>', unsafe_allow_html=True)

k1,k2,k3,k4,k5 = st.columns(5, gap="large")

def kpi(col, title, num, sub, variant, emoji):
    with col:
        st.markdown(f'''
        <div class="kpi {variant}">
          <div>
            <h4>{title}</h4>
            <div class="num">{num}</div>
            <div class="sub">{sub}</div>
          </div>
          <div class="dot">{emoji}</div>
        </div>
        ''', unsafe_allow_html=True)

kpi(k1,"TOTAL DE NOTAS", m.get("total_notas", 0), "Notas analisadas", "neutral","🧾")
kpi(k2,"CONFERIDAS", m.get("conferidas", 0), "Compatíveis", "success","✅")
kpi(k3,"DIVERGENTES", m.get("divergentes", 0), "Valores diferentes", "danger","⛔")
kpi(k4,"AUSENTES ADM", m.get("ausentes_adm", 0), "Faltando no ADM", "warn","⚠️")
kpi(k5,"AUSENTES FLEX", m.get("ausentes_flex", 0), "Faltando no Flex", "warn","⚠️")

st.write("")
st.markdown('<div class="l-card"><h3 style="margin:0;font-weight:900;">Resultado da Conferência</h3><p style="margin:6px 0 0 0;color:rgba(17,24,39,.6);font-size:13px;">Clique e filtre para ver os detalhes completos</p></div>', unsafe_allow_html=True)
st.write("")

tabs = ["Todos", "Conferidos", "Divergentes", "Ausentes ADM", "Ausentes Flex"]
counts = {"Todos": m.get("total_notas", 0), "Conferidos": m.get("conferidas", 0), "Divergentes": m.get("divergentes", 0), "Ausentes ADM": m.get("ausentes_adm", 0), "Ausentes Flex": m.get("ausentes_flex", 0)}
choice = st.radio(" ", [f"{t}  ({counts[t]})" for t in tabs], horizontal=True, label_visibility="collapsed")
choice_key = choice.split("  (")[0]

search = st.text_input("Buscar (número, série ou motivo)", placeholder="Ex.: 15186, 201, Divergência de VALOR", label_visibility="collapsed")

if sefaz_df.empty:
    st.info("Carregue o arquivo SEFAZ para ver os resultados.")

    base = (full_df.copy() if isinstance(full_df, pd.DataFrame) and not full_df.empty else alerts.copy())

    if choice_key == "Divergentes":
        base = base[base["motivo"].fillna("").str.contains("diverg", case=False)] if not base.empty else base
    elif choice_key == "Ausentes ADM":
        base = base[base.get("status_adm").astype(str).isin(["NAO_ENCONTRADO","SEM_ARQUIVO"])] if not base.empty else base
    elif choice_key == "Ausentes Flex":
        base = base[base.get("status_flex").astype(str).isin(["NAO_ENCONTRADO","SEM_ARQUIVO"])] if not base.empty else base
    elif choice_key == "Conferidos":
        # conferidos agora vêm da tabela completa (motivo = Conferido)
        if base.empty:
            base = base

            base = base[base.get("motivo").astype(str).str.lower().eq("conferido")]

    if search and not base.empty:
        s = search.lower().strip()
        mask = pd.Series(False, index=base.index)
        for col in [c for c in base.columns if c in ["serie","numero","motivo"]]:
            mask = mask | base[col].astype(str).str.lower().str.contains(s, na=False)
        base = base[mask]

    if not base.empty:
        sort_cols = [c for c in ["serie","numero","motivo"] if c in base.columns]
        if sort_cols:
            base = base.sort_values(sort_cols)

    if base.empty:
        st.success("Sem registros nesse filtro ✅")

        st.dataframe(style_table(base), use_container_width=True, height=520)

st.write("")
d1, d2 = st.columns([1,2])
with d1:
    if not sefaz_df.empty:
        xls = excel_download({"SEFAZ": sefaz_df, "ADM": adm_df, "FLEX": flex_df, "ALERTAS": alerts})
        st.download_button("Baixar relatório", data=xls, file_name="auditoria_nfce.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
with d2:
    st.caption("Dica: use os filtros (pílulas) + busca para isolar divergências e ausências rapidamente.")